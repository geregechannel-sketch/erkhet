UBCab Turbo v0.29.6 TEST
=========================
Separate test package: com.local.ubcabturbo296

Purpose:
- UBCab Driver 4.3.84 / build 708 live-tree test.
- After 20:00: tomorrow selected once.
- Refresh via real Accessibility ACTION_CLICK node only.
- Target cadence 500 ms (2 Hz).
- Acceptance probes at 20 / 45 / 80 ms after refresh/events.
- No coordinate tap / no dispatchGesture.
- <=150 minute scheduled orders blocked when time can be verified.
- XL-Van blocked.
- Ordinary incoming ride screen and Start/End trip screens are not auto-clicked.

Before test:
1. Disable old UBCab helper Accessibility.
2. Disable Tino helper Accessibility.
3. Run INSTALL_UBCAB_TURBO_0296_TEST.bat.
4. Enable 'UBCab Turbo v0.29.6 TEST' in Accessibility.
5. Open UBCab Driver -> Scheduled orders -> List.

This is a controlled TEST build, not yet a drop-in replacement for v0.29.2 reminder/history functions.
