@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
adb.exe start-server >nul 2>&1
set "DEVICE="
set "COUNT=0"
for /f "skip=1 tokens=1,2" %%A in ('adb.exe devices') do (
  if "%%B"=="device" (
    set "DEVICE=%%A"
    set /a COUNT+=1
  )
)
if "%COUNT%"=="0" (
  echo ERROR: No authorized Android device. Unlock device, enable USB debugging and tap Allow.
  adb.exe devices -l
  pause
  exit /b 1
)
if not "%COUNT%"=="1" (
  echo ERROR: Connect exactly ONE Android device.
  adb.exe devices -l
  pause
  exit /b 1
)
echo Installing UBCab Turbo v0.29.6 TEST on %DEVICE%...
adb.exe -s "%DEVICE%" install -r "UBCabTurbo-v0.29.6-TEST.apk"
if errorlevel 1 (
  echo INSTALL FAILED.
  pause
  exit /b 1
)
echo.
echo Installed. This TEST app uses package com.local.ubcabturbo296 and does NOT replace the old helper.
echo IMPORTANT: disable old UBCab helper and Tino Accessibility before enabling this TEST service.
adb.exe -s "%DEVICE%" shell am start -a android.settings.ACCESSIBILITY_SETTINGS >nul 2>&1
pause
